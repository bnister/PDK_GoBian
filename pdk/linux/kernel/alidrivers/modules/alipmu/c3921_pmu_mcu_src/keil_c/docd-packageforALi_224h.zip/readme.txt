::****************************************************************************::
:: Copyright (c) 1999-2006  Digital Core Design  DCD                          ::
::****************************************************************************::
:: Please review the terms of the license agreement before using this product ::
:: If  you  are  not an authorized user, please destroy this source code file ::
:: and  notify  DCD  immediately  that  you  inadvertently   received   an    ::
:: unauthorized copy.                                                         ::
::****************************************************************************::

DoCD Software package

Overview
::::::::::::::
   The  received  CD-ROM  contains  DCD  on  Chip  Debug  Software  and related
   documents  in  PDF  files.  DCD  on  Chip  Debug Software, Hardware Assisted 
   Debugger  (HAD2) and  Debug  IP Core  create complete DoCD(tm) Debug System.

Supplied Files 
::::::::::::::
   readme.txt                    : This file
   install.txt                   : Installation instruction
   history.txt                   : DCD Debug Software releases history
   .\HARDWARE\
      had2_ds.pdf                : Hardware Assisted Debugger specification
   .\SOFTWARE\
      docd-setup.exe             : Windows 98/NT/ME/2000/XP (r) DoCD Software
      docd-license.txt           : DCD on Chip Debug Software license
      docd2_ds.pdf               : On-chip debug system datasheet
     .\Keil_uVision\
        docd_uvision2_an.pdf     : DoCD Target driver installation note
        dcdsim_uvision2_an.pdf   : DCD simulator driver installation note
        DoCDKeil-setup.exe       : DCD Simulator & Target driver for Keil 
     .\DRIVERS\
        docdusb.sys              : DoCD USB driver used during Windows installation
        docdusb.inf              : INF fiel of DoCD USB driver

Support
::::::::::::::
   Although  every  effort  has  been  made  to ensure that this core functions
   correctly,  if  a problem is encountered please contact Digital Core Design:

      Technical Support Hotline   : +48-32-2828266
      Fax                         : +48-32-2827437
      E-mail                      : support@dcd.com.pl
